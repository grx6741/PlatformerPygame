from engine import Game

app = Game()

app.run()
